#asm
       ORG $7000
#endasm
