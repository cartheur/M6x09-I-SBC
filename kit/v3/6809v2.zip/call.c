char a;

delay(n)
char n;
{
  a=n;
}

main()
{
  delay(1);
}